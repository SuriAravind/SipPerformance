import com.google.code.externalsorting.ExternalSort;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Created by Suriyanarayanan K
 * on 01/07/20 10:27 AM.
 */
public class CheckingIdsFileMain {

    public static void main(String[] args) {

        //  String sipIdsFileName1 = "/Users/apple/Documents/Rajesh/Sip_Performance/87453736-878979-989890/table_contact.ids";
        //  String queryIdsFileName = "/Users/apple/Documents/Rajesh/Sip_Performance/QueryOutput/table_contact.txt";

        //String sipIdsFileName1 = "/Users/apple/Documents/Rajesh/Sip_Performance/87453736-878979-989890/table_contact_role.ids";
        //String queryIdsFileName = "/Users/apple/Documents/Rajesh/Sip_Performance/QueryOutput/table_contact_role.txt";

        String sipIdsFileName1 = "/Users/apple/Documents/Rajesh/Sip_Performance/Input/RecordFile2July20_1/MainTableValues_sorted.txt";
        String queryIdsFileName = "/Users/apple/Documents/Rajesh/Sip_Performance/Input/Checking Record File/MainTableValues.txt";

        List<File> l = null;
        try {
            l = ExternalSort.sortInBatch(new File(sipIdsFileName1));
            ExternalSort.mergeSortedFiles(l, new File(sipIdsFileName1), ExternalSort.defaultcomparator, true);
        } catch (IOException e) {
            e.printStackTrace();
        }

        /*List<File> l1 = null;
        try {
            l1 = ExternalSort.sortInBatch(new File(queryIdsFileName));
            ExternalSort.mergeSortedFiles(l1, new File(queryIdsFileName), ExternalSort.defaultcomparator, true);
        } catch (IOException e) {
            e.printStackTrace();
        }
*/



        /*Set<String> sipIdsList = null;
        try {
            Stream<String> fileLines = Files.lines(Paths.get(sipIdsFileName1));
            // sipIdsList = fileLines.map(line -> line.substring(line.indexOf("=") + 1, line.indexOf(" and ")).trim()).collect(Collectors.toSet());
            sipIdsList = fileLines.collect(Collectors.toSet());
        } catch (IOException e) {
            e.printStackTrace();
        }


        List<String> queryIdsList = null;
        try {
            Stream<String> fileLines = Files.lines(Paths.get(queryIdsFileName));
            queryIdsList = fileLines.collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("july 1 Size :" + sipIdsList.size());
        System.out.println("Old  lSize :" + queryIdsList.size());
        queryIdsList.removeAll(sipIdsList);
        System.out.println("Distinct Elements Size :" + queryIdsList.size());
        System.out.println("Distinct Elements :" + queryIdsList);*/
    }
}
