package utility;

import org.apache.log4j.Logger;

import java.io.*;

/**
 * Created by Suriyanarayanan K
 * on 13/02/20 8:31 PM.
 */
public class Utilities {

    private Logger LOGGER = Logger.getLogger(this.getClass().getName());
    /**
     * Method Name:getMetadataFileContent
     * Convert metadata file into string
     */
    public  String getFileContent(File metadataFile) {
        BufferedReader reader = null;
        StringBuilder stringBuilder = new StringBuilder();
        try {
            reader = new BufferedReader(new FileReader(metadataFile));
            String line = null;
            String ls = System.getProperty("line.separator");
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
            reader.close();
        } catch (FileNotFoundException e) {
            LOGGER.error(e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            LOGGER.error(e.getMessage());
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }


}
