package bean.sip_project;

import lombok.Builder;
import lombok.Data;

import java.util.*;

/**
 * Created by Suriyanarayanan K
 * on 28/05/20 6:27 PM.
 */
@Data
public class SipTableList {
    @Builder.Default
    private String name = "";   // 1.1
    @Builder.Default
    private String columnQuery = ""; // 1.2
    @Builder.Default
    private Map<String, String> oldModifiedColumns = new LinkedHashMap<>(); //1.3
    @Builder.Default
    private String filterQuery = ""; //1.4
    @Builder.Default
    private Set<String> blobColumns = new LinkedHashSet<>(); //1.5
    @Builder.Default
    private Set<String> keyColumns = new LinkedHashSet<>(); //1.6
    @Builder.Default
    private Set<String> extraColumn = new LinkedHashSet<>(); //1.7
    @Builder.Default
    private Set<String> relatedTables = new LinkedHashSet<>(); //1.8
    @Builder.Default
    private Set<String> relationshipList = new LinkedHashSet<>(); //1.9

}
