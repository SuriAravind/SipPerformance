package bean.sip_project;

import lombok.Builder;
import lombok.Data;

import java.util.*;

/**
 * Created by Suriyanarayanan K
 * on 28/05/20 6:25 PM.
 */
@Data
public class SipProjectJson {

    @Builder.Default
    private Map<String, SipTableList> sipTableListMap = new LinkedHashMap<>();  //1
    @Builder.Default
    private List<String> selectedTableList = new ArrayList<>(); //2
    @Builder.Default
    private TreeMap<String, String> charReplace = new TreeMap<>(); //3
}
