package bean.json;

/**
 * Created by Suriyanarayanan K
 * on 28/05/20 6:11 PM.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DatabaseConfig {
    @JsonProperty("databaseId")
    private String databaseID;
}
