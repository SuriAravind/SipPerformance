package bean.json;


import com.fasterxml.jackson.annotation.*;
import lombok.Data;

@Data
public class FilterAndOrderConfig {
    @JsonProperty("filterConfig")
    private String filterConfig;
    @JsonProperty("filterFinalQuery")
    private String filterFinalQuery;
}
