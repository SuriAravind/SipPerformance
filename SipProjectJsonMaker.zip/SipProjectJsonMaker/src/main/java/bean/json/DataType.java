package bean.json;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.io.IOException;

public enum DataType {
    BIGINT, CHAR, DATETIME, INT, NUMERIC, SMALLDATETIME, SMALLINT, TEXT, TINYINT, VARCHAR, BLOB,DECIMAL;

    @JsonValue
    public String toValue() {
        switch (this) {
            case BIGINT:
                return "bigint";
            case CHAR:
                return "char";
            case DATETIME:
                return "datetime";
            case INT:
                return "int";
            case NUMERIC:
                return "numeric";
            case SMALLDATETIME:
                return "smalldatetime";
            case SMALLINT:
                return "smallint";
            case TEXT:
                return "text";
            case TINYINT:
                return "tinyint";
            case VARCHAR:
                return "varchar";
            case BLOB:
                return "blob";
            case DECIMAL:
                return "decimal";
        }
        return null;
    }

    @JsonCreator
    public static DataType forValue(String value) throws IOException {
        switch (value) {
            case "bigint":
                return BIGINT;
            case "char":
                return CHAR;
            case "datetime":
                return DATETIME;
            case "int":
                return INT;
            case "numeric":
                return NUMERIC;
            case "smalldatetime":
                return SMALLDATETIME;
            case "smallint":
                return SMALLINT;
            case "text":
                return TEXT;
            case "tinyint":
                return TINYINT;
            case "varchar":
                return VARCHAR;
            case "blob":
                return BLOB;
            case "decimal":
                return DECIMAL;
            default:
                throw new IOException("Cannot deserialize DataType");
        }
    }
}
