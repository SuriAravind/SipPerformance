package bean.json;

import java.util.*;
import com.fasterxml.jackson.annotation.*;
import lombok.Data;

@Data
public class RelatedTableInfo {
    @JsonProperty("tableId")
    private String tableID;
    @JsonProperty("tableName")
    private String tableName;
}
