package bean.json;

/**
 * Created by Suriyanarayanan K
 * on 28/05/20 6:12 PM.
 */
import java.util.*;
import com.fasterxml.jackson.annotation.*;
import lombok.Data;

@Data
public class TableDetailsList {
    @JsonProperty("tableId")
    private String tableID;
    @JsonProperty("tableName")
    private String tableName;
    @JsonProperty("isMainTable")
    private boolean isMainTable;
    @JsonProperty("modifiedTableName")
    private String modifiedTableName;
    @JsonProperty("columnList")
    private List<ColumnList> columnList;
    @JsonProperty("usrDefinedColumnList")
    private Object usrDefinedColumnList;
    @JsonProperty("filterAndOrderConfig")
    private FilterAndOrderConfig filterAndOrderConfig;
    @JsonProperty("extractDataConfig")
    private Object extractDataConfig;
    @JsonProperty("ingestionDataConfig")
    private Object ingestionDataConfig;
    @JsonProperty("relatedTableInfo")
    private List<RelatedTableInfo> relatedTableInfo;
    @JsonProperty("isSelected")
    private boolean isSelected;
    @JsonProperty("isOverride")
    private Object isOverride;
}
