
package bean.json;


import com.fasterxml.jackson.annotation.*;
import lombok.Data;

@Data
public class ColumnList {
    @JsonProperty("originalColumnName")
    private String originalColumnName;
    @JsonProperty("modifiedColumnName")
    private String modifiedColumnName;
    @JsonProperty("dataType")
    private DataType dataType;
    @JsonProperty("isPrimaryKey")
    private boolean isPrimaryKey;
    @JsonProperty("userColumnQuery")
    private Object userColumnQuery;
    @JsonProperty("viewQuery")
    private Object viewQuery;
    @JsonProperty("isKey")
    private boolean isKey;
    @JsonProperty("isSelected ")
    private Boolean columnListIsSelected;
    @JsonProperty("isSelected")
    private Boolean isSelected;
}
