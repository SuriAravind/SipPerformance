package bean.json;

import java.util.*;
import com.fasterxml.jackson.annotation.*;
import lombok.Data;

@Data
public class GraphDetails {
    @JsonProperty("data")
    private String data;
    @JsonProperty("selectedValues")
    private String selectedValues;
    @JsonProperty("joinListMap")
    private String joinListMap;
    @JsonProperty("selectedPrimaryTable")
    private String selectedPrimaryTable;
}
