package bean.json;



import java.util.List;

/**
 * Created by Suriyanarayanan K
 * on 28/05/20 5:15 PM.
 */

import java.util.*;
import com.fasterxml.jackson.annotation.*;
import lombok.Data;

@Data
public class InputJsonBeanDetails {
    @JsonProperty("id")
    private String id;
    @JsonProperty("createdAt")
    private long createdAt;
    @JsonProperty("updatedAt")
    private long updatedAt;
    @JsonProperty("corelatedInstanceId")
    private Object corelatedInstanceID;
    @JsonProperty("instanceId")
    private Object instanceID;
    @JsonProperty("userId")
    private String userID;
    @JsonProperty("workspaceId")
    private String workspaceID;
    @JsonProperty("databaseConfig")
    private DatabaseConfig databaseConfig;
    @JsonProperty("ertJobParams")
    private ErtJobParams ertJobParams;
    @JsonProperty("mmrVersion")
    private String mmrVersion;
    @JsonProperty("tableDetailsList")
    private List<TableDetailsList> tableDetailsList;
    @JsonProperty("ertJobStatus")
    private String ertJobStatus;
    @JsonProperty("selectedTableIdList")
    private List<String> selectedTableIDList;
    @JsonProperty("schemaResultsTableCount")
    private long schemaResultsTableCount;
    @JsonProperty("ingestionDataConfig")
    private Object ingestionDataConfig;
    @JsonProperty("extractDataConfig")
    private ExtractDataConfig extractDataConfig;
    @JsonProperty("isIngest")
    private boolean isIngest;
    @JsonProperty("releatedJobId")
    private String releatedJobID;
    @JsonProperty("updatedBy")
    private String updatedBy;
    @JsonProperty("isExtract")
    private boolean isExtract;
    @JsonProperty("isLiveArchiveJob")
    private boolean isLiveArchiveJob;
    @JsonProperty("idsFilePath")
    private Object idsFilePath;
    @JsonProperty("liveArchivalLastRunDate")
    private long liveArchivalLastRunDate;
    @JsonProperty("deleteData")
    private boolean deleteData;
    @JsonProperty("tableListForDelete")
    private Object tableListForDelete;
    @JsonProperty("graphDetails")
    private GraphDetails graphDetails;
    @JsonProperty("isCustomJob")
    private boolean isCustomJob;
    @JsonProperty("customJobInfo")
    private Object customJobInfo;
    @JsonProperty("softDeleted")
    private boolean softDeleted;
}
