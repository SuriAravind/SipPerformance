package bean.json;

/**
 * Created by Suriyanarayanan K
 * on 28/05/20 6:13 PM.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ExtractDataConfig {
    @JsonProperty("titleName")
    private Object titleName;
    @JsonProperty("applicationName")
    private String applicationName;
    @JsonProperty("holdingName")
    private String holdingName;
    @JsonProperty("xmlFileSplitSize")
    private long xmlFileSplitSize;
}
