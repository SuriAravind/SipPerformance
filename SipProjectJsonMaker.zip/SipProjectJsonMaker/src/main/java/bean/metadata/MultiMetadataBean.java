package bean.metadata;

/**
 * Created by Suriyanarayanan K
 * on 13/02/20 5:39 PM.
 */
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Locale;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor

public class MultiMetadataBean {
    @JacksonXmlProperty(localName = "schemaMetadataList")
    private List<SchemaMetadata> schemaMetadataList;
    @JacksonXmlProperty(isAttribute = true, localName = "DBS")
    private String DBS;
    @JacksonXmlProperty(isAttribute = true, localName = "HOST")
    private String HOST;
    @JacksonXmlProperty(isAttribute = true, localName = "PORT")
    private Integer PORT;
    @JacksonXmlProperty(isAttribute = true, localName = "DATABASE")
    private String DATABASE;
    @JacksonXmlProperty(isAttribute = true, localName = "SCHEMA")
    private String SCHEMA;
    @JacksonXmlProperty(isAttribute = true, localName = "FULLORSELECTED")
    private String FULLORSELECTED;
    @JacksonXmlProperty(isAttribute = true, localName = "SELECTED")
    private String SELECTED;
    @JacksonXmlProperty(isAttribute = true, localName = "caseSensitive")
    private boolean caseSensitive;
    @JacksonXmlProperty(isAttribute = true, localName = "defaultSchema")
    private String defaultSchema;
    @JacksonXmlProperty(isAttribute = true, localName = "locale")
    private Locale locale;
    @JacksonXmlProperty(isAttribute = true, localName = "validatingOnIngest")
    private boolean validatingOnIngest;
}
