package bean.metadata;

/**
 * Created by Suriyanarayanan K
 * on 13/02/20 5:41 PM.
 */


import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TableMetadata {


    private RelationshipList relationshipList;
    private Integer recordCount;
    private String name;
    @JacksonXmlProperty(localName = "columnList")
    private List<ColumnList> columnList;
}
