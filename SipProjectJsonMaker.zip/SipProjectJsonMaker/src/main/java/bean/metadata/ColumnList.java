package bean.metadata;

/**
 * Created by Suriyanarayanan K
 * on 13/02/20 5:42 PM.
 */

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ColumnList {

    private String name;
    private boolean index;
    private Integer typeLength;
    private String type;
    private Integer ordinal;
}
