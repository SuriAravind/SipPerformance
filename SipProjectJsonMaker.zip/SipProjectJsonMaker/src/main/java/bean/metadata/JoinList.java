package bean.metadata;

/**
 * Created by Suriyanarayanan K
 * on 13/02/20 5:43 PM.
 */

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JoinList {

    private String isPkTable;
    private String fkTable;
    private String pkColumn;
    private String pkTable;
    private String fkColumn;
}
