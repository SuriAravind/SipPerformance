package bean.metadata;

/**
 * Created by Suriyanarayanan K
 * on 13/02/20 5:43 PM.
 */

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Relationship {

    @JacksonXmlProperty(localName = "joinList")
    private List<JoinList> joinList ;
    private String name;
    private String _TYPE;
    private String cardinality;
}
