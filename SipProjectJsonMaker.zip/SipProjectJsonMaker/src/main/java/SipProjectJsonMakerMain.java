import processor.ColumnDataTypeCreator;
import processor.Processor;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by Suriyanarayanan K
 * on 28/05/20 3:26 PM.
 */
public class SipProjectJsonMakerMain {


    public static void main(String[] args) {

        // column data type creator
        boolean columnDataType = false;
        if (columnDataType) {
            String metadataFilePath = args[0];

            ColumnDataTypeCreator columnDataTypeCreator = new ColumnDataTypeCreator(metadataFilePath);
            columnDataTypeCreator.startColumnDataProcess();
        } else {
            String metadataFilePath = args[0];
            String jsonFileLocation = args[1];
            String outputLocation = args[2];
            String outputFileName = args[3];

            System.out.println("SipProjectJsonMaker Creation Start " + new Timestamp(new Date().getTime()));
            Processor processor = new Processor(metadataFilePath, jsonFileLocation, outputLocation, outputFileName);
            processor.setValuesIntoBean();
            processor.start();
            System.out.println("SipProjectJsonMaker Creation End " + new Timestamp(new Date().getTime()));
        }
    }
}
