package processor;

import bean.json.ColumnList;
import bean.json.DataType;
import bean.json.InputJsonBeanDetails;
import bean.json.TableDetailsList;
import bean.metadata.JoinList;
import bean.metadata.MultiMetadataBean;
import bean.metadata.Relationship;
import bean.metadata.TableMetadata;
import bean.sip_project.SipProjectJson;
import bean.sip_project.SipTableList;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import utility.Utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by Suriyanarayanan K
 * on 28/05/20 6:17 PM.
 */
public class Processor {

    String metadataFilePath;
    String jsonFileLocation;
    String outputLocation;
    String outputFileName;
    MultiMetadataBean multiMetadataBean;
    InputJsonBeanDetails inputJsonBeanDetails;


    public Processor(String metadataFilePath, String jsonFileLocation, String outputLocation, String outputFileName) {
        this.metadataFilePath = metadataFilePath;
        this.jsonFileLocation = jsonFileLocation;
        this.outputLocation = outputLocation;
        this.outputFileName = outputFileName;
    }


    public void setValuesIntoBean() {
        File metadataFile = new File(metadataFilePath);
        Utilities multiMetadataUtility = new Utilities();
        String metadataFileContent = multiMetadataUtility.getFileContent(metadataFile);
        XmlMapper xmlMapper = new XmlMapper();
        xmlMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try {
            multiMetadataBean = xmlMapper.readValue(metadataFileContent, MultiMetadataBean.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }


        File jsonFile = new File(jsonFileLocation);
        String jsonFileLines = multiMetadataUtility.getFileContent(jsonFile);
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            inputJsonBeanDetails = objectMapper.readValue(jsonFileLines, InputJsonBeanDetails.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

    }

    public void start() {

        SipProjectJson sipProjectJson = new SipProjectJson();
        List<TableDetailsList> selectedTableDetailsList = inputJsonBeanDetails.getTableDetailsList().stream().filter(tableDetailsList -> tableDetailsList.isSelected()).collect(Collectors.toList());


        for (TableDetailsList inputJsonTableDetails : selectedTableDetailsList) {

            String tableName = inputJsonTableDetails.getTableName();

            SipTableList sipTableList = new SipTableList();

            sipTableList.setName(tableName); //1.1
            if (inputJsonTableDetails.getFilterAndOrderConfig().getFilterFinalQuery() != null && !inputJsonTableDetails.getFilterAndOrderConfig().getFilterFinalQuery().isEmpty()) {
                sipTableList.setFilterQuery(inputJsonTableDetails.getFilterAndOrderConfig().getFilterFinalQuery().replace("where", "")); //1.4
            }


            Set<String> keyColumns = new LinkedHashSet<>();
            Map<String, String> relationShipList = new LinkedHashMap<>();

            TableMetadata tableMetadata = multiMetadataBean.getSchemaMetadataList().get(0).getTableMetadataList().stream().filter(table -> table.getName().equalsIgnoreCase(tableName)).findFirst().get();
            for (Relationship relationship : tableMetadata.getRelationshipList().getRelationship()) {
                List<JoinList> joinList = relationship.getJoinList();
                List<String> joinRelationShipList = new ArrayList<>();
                String fkTableName = "";
                for (JoinList joins : joinList) {
                    if (joins.getPkTable().equalsIgnoreCase(tableName)) {
                        fkTableName = joins.getFkTable();
                        keyColumns.add(joins.getPkColumn());
                        joinRelationShipList.add(joins.getFkTable() + "." + joins.getFkColumn() + " = " + joins.getPkTable() + "." + joins.getPkColumn());
                    } else {
                        fkTableName = joins.getPkTable();
                        keyColumns.add(joins.getFkColumn());
                        joinRelationShipList.add(joins.getPkTable() + "." + joins.getPkColumn() + " = " + joins.getFkTable() + "." + joins.getFkColumn());
                    }
                }
                if (relationShipList.containsKey(fkTableName)) {
                    relationShipList.put(fkTableName, relationShipList.get(fkTableName) + " or " + " ( " + String.join(" and ", joinRelationShipList) + " ) ");
                } else {
                    relationShipList.put(fkTableName, " ( " + String.join(" and ", joinRelationShipList) + " ) ");
                }
            }

            sipTableList.setKeyColumns(keyColumns); //1.6


            Set<String> originalRelationsShipList = new LinkedHashSet<>();
            for (Map.Entry<String, String> relationShip : relationShipList.entrySet()) {
                originalRelationsShipList.add(relationShip.getKey() + "->" + "(" + relationShip.getValue() + ")");
            }
            sipTableList.setRelationshipList(originalRelationsShipList); //1.9
            sipTableList.setRelatedTables(relationShipList.keySet()); //1.8


            String keyColumnsQuery = columnQueryFramer(tableName, keyColumns);

            Set<String> userColumnList = new LinkedHashSet<>();
            Set<String> blobColumn = new LinkedHashSet<>();

            Map<String, String> oldModifiedColumns = new LinkedHashMap<>();

            for (ColumnList columnList : inputJsonTableDetails.getColumnList()) {

                if (columnList.getIsSelected()) {
                    userColumnList.add(columnList.getOriginalColumnName());
                    oldModifiedColumns.put(columnList.getOriginalColumnName(), columnList.getModifiedColumnName());
                }
                if (columnList.getDataType() == DataType.BLOB) {
                    blobColumn.add(columnList.getOriginalColumnName());
                }
            }


            Set<String> tempFindExtraColumnList = new LinkedHashSet<>();
            tempFindExtraColumnList.addAll(keyColumns);
            tempFindExtraColumnList.removeAll(userColumnList);
            if (!tempFindExtraColumnList.isEmpty()) {
                sipTableList.setExtraColumn(tempFindExtraColumnList);   //1.7
            }
            if (!blobColumn.isEmpty()) {
                sipTableList.setBlobColumns(blobColumn); //1.5
            }

            Set<String> nonUserKeyColumnList = new LinkedHashSet<>();
            nonUserKeyColumnList.addAll(userColumnList);
            nonUserKeyColumnList.removeAll(keyColumns);

            String nonKeyColumnQuery = "";
            if (!nonUserKeyColumnList.isEmpty()) {
                nonKeyColumnQuery = columnQueryFramer(tableName, nonUserKeyColumnList);
            }

            sipTableList.setColumnQuery(keyColumnsQuery + (nonKeyColumnQuery.isEmpty() ? "" :","+nonKeyColumnQuery)); // 1.2
            sipTableList.setOldModifiedColumns(oldModifiedColumns); //1.3

            sipProjectJson.getSipTableListMap().put(tableName, sipTableList); // 1
            sipProjectJson.getSelectedTableList().add(tableName);   // 2
        }


        JSONObject outputObject = new JSONObject();

        outputObject.put("tableList", getTableDetailsJsonArray(sipProjectJson.getSipTableListMap()));
        JSONArray selectedTableList = new JSONArray();
        for (String selectedTable : sipProjectJson.getSelectedTableList()) {
            selectedTableList.put(selectedTable);
        }
        outputObject.put("selectedTableList", selectedTableList);

        try {
            PrintWriter printWriter = new PrintWriter(new File(outputLocation + File.separator + outputFileName + "_InputJson.json"));
            printWriter.write(outputObject.toString());
            printWriter.flush();
            printWriter.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


    }

    private JSONArray getTableDetailsJsonArray(Map<String, SipTableList> sipTableListMap) {
        JSONArray tableDetails = new JSONArray();

        for (Map.Entry<String, SipTableList> tableListEntry : sipTableListMap.entrySet()) {

            JSONObject table = new JSONObject();
            table.put("name", tableListEntry.getValue().getName());
            table.put("columnQuery", tableListEntry.getValue().getColumnQuery());
            table.put("filterQuery", tableListEntry.getValue().getFilterQuery());
            table.put("blobColumn", String.join(",", tableListEntry.getValue().getBlobColumns()));
            JSONArray keyColumns = new JSONArray();
            for (String keyColumn : tableListEntry.getValue().getKeyColumns()) {
                keyColumns.put(keyColumn);
            }
            table.put("keyColumns", keyColumns);

            JSONArray extraColumns = new JSONArray();
            for (String extraColumn : tableListEntry.getValue().getExtraColumn()) {
                extraColumns.put(extraColumn);
            }
            table.put("extraColumns", extraColumns);

            JSONArray relatedTables = new JSONArray();
            for (String relatedTable : tableListEntry.getValue().getRelatedTables()) {
                relatedTables.put(relatedTable);
            }
            table.put("relatedTables", relatedTables);


            JSONArray relationshipList = new JSONArray();
            for (String relationship : tableListEntry.getValue().getRelationshipList()) {
                relationshipList.put(relationship);
            }
            table.put("relationshipList", relationshipList);


            JSONObject oldModifyColumnObject = new JSONObject();
            for (Map.Entry<String, String> oldModifyColumn : tableListEntry.getValue().getOldModifiedColumns().entrySet()) {
                oldModifyColumnObject.put(oldModifyColumn.getKey(), oldModifyColumn.getValue());
            }
            table.put("oldModifyColumn", oldModifyColumnObject);

            tableDetails.put(table);
        }
        return tableDetails;
    }


    private String columnQueryFramer(String tableName, Set<String> columnList) {

        List<String> columnQuery = new ArrayList<>();
        for (String column : columnList) {
            columnQuery.add(tableName + "." + column + " as \"" + tableName + "." + column + "\"");
        }
        return String.join(",", columnQuery);
    }
}
