package processor;


import bean.metadata.ColumnList;
import bean.metadata.MultiMetadataBean;
import bean.metadata.TableMetadata;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.json.JSONObject;
import utility.Utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Types;

/**
 * Created by Suriyanarayanan K
 * on 04/06/20 8:08 PM.
 */
public class ColumnDataTypeCreator {
    String metadataFilePath;
    Utilities utilities = new Utilities();
    MultiMetadataBean multiMetadataBean;

    public ColumnDataTypeCreator(String metadataFilePath) {
        this.metadataFilePath = metadataFilePath;
    }

    public void startColumnDataProcess() {
        String metadataFileContent = utilities.getFileContent(new File(metadataFilePath));
        XmlMapper xmlMapper = new XmlMapper();
        xmlMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try {
            multiMetadataBean = xmlMapper.readValue(metadataFileContent, MultiMetadataBean.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }


        JSONObject columnDatatype = new JSONObject();
        for (TableMetadata tableMetadata : multiMetadataBean.getSchemaMetadataList().get(0).getTableMetadataList()) {
            String tableName = tableMetadata.getName();
            for (ColumnList columnList : tableMetadata.getColumnList()) {

                if (columnList.getTypeLength() > 255) {
                    columnDatatype.put(tableName + "." + columnList.getName(), Types.CLOB);
                } else if (columnList.getType().equalsIgnoreCase("DATETIME")) {
                    columnDatatype.put((tableName.toLowerCase() + "." + columnList.getName()), Types.TIME_WITH_TIMEZONE);
                } else {
                    columnDatatype.put((tableName.toLowerCase() + "." + columnList.getName()), Types.VARCHAR);
                }
            }
        }
        File output = new File("columnDataType.json");
        try {
            PrintWriter printWriter = new PrintWriter(output);
            printWriter.write(columnDatatype.toString());
            printWriter.flush();
            printWriter.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}
